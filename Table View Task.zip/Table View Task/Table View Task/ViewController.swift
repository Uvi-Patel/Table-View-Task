//
//  ViewController.swift
//  Table View Task
//
//  Created by MAC on 09/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblviewOne: UITableView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var btnAdd: UIButton!
    
    let cellIdentifier = "Datacell"
    
    let stringArr = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblviewOne.dataSource = self
        tblviewOne.delegate = self
        btnAdd.addTarget(self, action: #selector(ClickToAdd(_:)), for: .touchUpInside)
        tblviewOne.register(UITableViewCell.self, forCellReuseIdentifier: self.cellIdentifier)
        tblviewOne.showsHorizontalScrollIndicator = false
        tblviewOne.showsVerticalScrollIndicator = false
        
        tblviewOne.delegate = self
        tblviewOne.dataSource = self
        tblviewOne.reloadData()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClickToAdd(_ sender: Any) {
        if let txt = txtName.text, !txt.isEmpty {
            self.stringArr.insert(txt, at: 0)
            tblviewOne.reloadData()
            txtName.text = nil
        }
    }
    
    // MARK: - Tableview Delegate method
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        if stringArr.count % 3 == 0 {
            return (stringArr.count / 3)
            
        }else{
            return (Int(stringArr.count/3)+1)
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.cellIdentifier , for: indexPath) // as! mycell
//        cell.frame = CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: tableView.frame.size.height)
        cell.subviews.forEach({$0.removeFromSuperview() })
        cell.selectionStyle = .none
       let scrollview = UIScrollView()
        scrollview.frame = CGRect(x: 0, y: 0, width: tblviewOne.frame.size.width, height: cell.frame.size.height)
       
        var xPostion = 0
        
        var Xindex = indexPath.row * 3
        for i in 0..<3 {
            
            if (Xindex < self.stringArr.count)
            {
                let lbl = UILabel()
                lbl.isUserInteractionEnabled = true
                lbl.frame = CGRect(x: CGFloat(xPostion), y: 10, width: 10000 ,
                                   height: 40)
                lbl.textAlignment = .center
                lbl.backgroundColor = .systemGray2
                lbl.text = (self.stringArr[Xindex] as! String)
                lbl.sizeToFit()
                lbl.adjustsFontSizeToFitWidth = true
                
                var CGzise = lbl.frame
                CGzise.size.width = lbl.frame.size.width + 50
                CGzise.size.height = lbl.frame.size.height + 20
                CGzise.origin.y = 0
                lbl.frame = CGzise
                
                scrollview.addSubview(lbl)
                
                let btnDlt = UIButton()
                btnDlt.frame = CGRect(x: CGFloat(xPostion) + lbl.frame.size.width - 15, y: lbl.frame.origin.y + 5 , width: 10, height: 10)
                btnDlt.setTitle("X", for:   .normal)
                btnDlt.backgroundColor = .red
                btnDlt.tag = 5000 + Xindex
                btnDlt.addTarget(self, action: #selector(clickToDlt(_:)), for: .touchUpInside)
                scrollview.addSubview(btnDlt)
                
                xPostion += (Int(lbl.frame.size.width)) + 10
            }
            Xindex = Xindex + 1
        }
//        tblviewOne.contentSize.width = CGFloat(xPostion)
//       tblviewOne.contentSize.width = CGFloat(xPostion)
//        cell.contentView = CGFloat(xPostion)
        //        tblviewOne.contentSize.width = CGFloat(xPostion)
        scrollview.contentSize.width = CGFloat(xPostion)
         cell.addSubview(scrollview)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    @IBAction func clickToDlt(_ sender: UIButton?) {
        print("\(sender?.tag)")
        let tag = sender!.tag - 5000
        stringArr.removeObject(at: tag)
        tblviewOne.reloadData()
        print("\(stringArr)")
        
    }
}
class mycell: UITableViewCell {
    @IBOutlet weak var myscrollview: UIScrollView!
    @IBOutlet weak var innnerv: UIView!
    
}
