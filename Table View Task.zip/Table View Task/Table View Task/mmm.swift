//
//  ViewController.swift
//  Table View Task
//
//  Created by MAC on 09/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

/*import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblviewOne: UITableView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var btnAdd: UIButton!
    let stringArr = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblviewOne.dataSource = self
        tblviewOne.delegate = self
        btnAdd.tag = 57775
        btnAdd.addTarget(self, action: #selector(ClickToAdd(_:)), for: .touchUpInside)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClickToAdd(_ sender: Any) {
        if let txt = txtName.text, !txt.isEmpty {
            self.stringArr.insert(txt, at: 0)
            tblviewOne.beginUpdates()
            tblviewOne.insertRows(at: [IndexPath(row: 0, section: 0)], with: .right)
            tblviewOne.endUpdates()
            
            txtName.text = nil
        }
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stringArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! cellControll
       
        cell.lblName.text = stringArr[indexPath.row] as! String

//        cell.lblName.text = "hello"
        return cell
        
    }
    
}
class cellControll:UITableViewCell{
    
    @IBOutlet weak var lblName: UILabel!
}*/

